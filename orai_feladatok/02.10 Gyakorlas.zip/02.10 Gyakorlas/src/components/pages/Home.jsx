import React from 'react'
import { Link } from 'react-router-dom'
export const Home = () =>
{
return
<div>
<h1>Kezdőlap</h1>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam quis quaerat vero perspiciatis vitae! Iste pariatur est enim sequi in ullam repellat sit consequuntur, amet eius quae labore officia earum!</p>
</div>

}