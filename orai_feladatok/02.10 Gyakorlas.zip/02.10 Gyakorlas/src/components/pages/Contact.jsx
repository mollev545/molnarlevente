import React from 'react'

export const Contact = () =>
{
return
<div>
<h1>Kapcsolat</h1>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam quis quaerat vero perspiciatis vitae! Iste pariatur est enim sequi in ullam repellat sit consequuntur, amet eius quae labore officia earum!</p>
</div>

}