import React from 'react'

export const Services = () =>
{
return
<div>
<h1>Szolgáltatások</h1>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil voluptatem placeat incidunt voluptatum repudiandae in minima illum libero qui autem tempora maiores nisi sapiente voluptatibus voluptate, laboriosam obcaecati perspiciatis necessitatibus, soluta eligendi inventore amet. Neque iusto officia optio temporibus nemo, nisi esse atque in. Illo, odit illum obcaecati laudantium placeat velit asperiores dicta natus aut accusantium repellat! Similique animi laboriosam illo cum architecto repellat laudantium! Id sint fugiat praesentium beatae eligendi nihil deserunt, deleniti maiores quae dolores quod, qui facilis, tempore quaerat sunt aspernatur similique! Consequatur illo officia quos possimus voluptatibus facilis dolor molestias? Inventore, facilis! Nam quia maxime aliquam?</p>
</div>

}